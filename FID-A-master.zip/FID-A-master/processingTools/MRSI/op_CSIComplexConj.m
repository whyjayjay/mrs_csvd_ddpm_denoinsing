function MRSIStruct = op_CSIComplexConj(MRSIStruct)
    MRSIStruct.data = conj(MRSIStruct.data);
    
end