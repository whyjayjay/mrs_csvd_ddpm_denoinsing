function ppm = getPPM(MRSIStruct)
    ppm = MRSIStruct.ppm;
end
