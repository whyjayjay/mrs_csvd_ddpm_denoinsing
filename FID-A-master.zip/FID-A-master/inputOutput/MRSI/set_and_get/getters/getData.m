function data = getData(MRSIStruct)
    data = MRSIStruct.data;
end
