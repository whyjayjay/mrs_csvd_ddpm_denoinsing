function affineMatrix = getAffineMatrix(MRSIStruct)
    affineMatrix = MRSIStruct.affineMatrix;
end
