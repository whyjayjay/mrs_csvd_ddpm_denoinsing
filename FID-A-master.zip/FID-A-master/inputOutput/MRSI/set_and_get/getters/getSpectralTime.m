function time = getSpectralTime(MRSIStruct)
    time = MRSIStruct.spectralTime;
end
