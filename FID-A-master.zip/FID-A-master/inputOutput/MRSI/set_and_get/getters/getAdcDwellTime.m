function adcDwellTime = getAdcDwellTime(MRSIStruct)
    adcDwellTime = MRSIStruct.adcDwellTime;
end