function referencePPM = getReferencePPM
    referencePPM = 4.65;
end