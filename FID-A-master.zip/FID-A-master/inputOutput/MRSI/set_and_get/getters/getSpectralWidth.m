function spectralWidth = getSpectralWidth(MRSIStruct)
    spectralWidth = MRSIStruct.spectralWidth;
end