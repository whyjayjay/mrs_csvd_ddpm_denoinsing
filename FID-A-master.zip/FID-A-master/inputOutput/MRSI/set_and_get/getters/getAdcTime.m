function adcTime = getAdcTime(MRSIStruct)
    adcTime = MRSIStruct.adcTime;
end