function dataSize = getSize(MRSIStruct)
    dataSize = MRSIStruct.sz;
end
