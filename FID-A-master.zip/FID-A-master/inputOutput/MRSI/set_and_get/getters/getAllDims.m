function allDims = getAllDims(MRSIStruct)
    allDims = MRSIStruct.dims;
end
