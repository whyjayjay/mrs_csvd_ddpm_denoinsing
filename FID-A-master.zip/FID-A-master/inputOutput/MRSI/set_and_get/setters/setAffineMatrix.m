function MRSIStruct = setAffineMatrix(MRSIStruct, newAffineMatrix)
    MRSIStruct.affineMatrix = newAffineMatrix;
end
