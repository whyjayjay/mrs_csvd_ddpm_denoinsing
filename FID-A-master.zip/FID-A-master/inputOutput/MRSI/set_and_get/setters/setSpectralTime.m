function MRSIStruct = setSpectralTime(MRSIStruct, newTime)
    MRSIStruct.spectralTime = newTime;
end
