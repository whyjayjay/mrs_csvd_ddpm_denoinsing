function MRSIStruct = setSpectralWidth(MRSIStruct, value)
    MRSIStruct.spectralWidth = value;
end