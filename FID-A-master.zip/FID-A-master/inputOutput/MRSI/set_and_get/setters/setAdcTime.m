function MRSIStruct = setAdcTime(MRSIStruct, value)
    MRSIStruct.adcTime = value;
end