function MRSIStruct = setSize(MRSIStruct, newSize)
    MRSIStruct.sz = newSize;
end