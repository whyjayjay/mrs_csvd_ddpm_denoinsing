function MRSIStruct = setPPM(MRSIStruct, newPPM)
    MRSIStruct.ppm = newPPM;
end
