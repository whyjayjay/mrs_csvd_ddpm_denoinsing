function MRSIStruct = setSpectralDwellTime(MRSIStruct, newSpectralDwellTime)
    MRSIStruct.spectralDwellTime = newSpectralDwellTime;
end