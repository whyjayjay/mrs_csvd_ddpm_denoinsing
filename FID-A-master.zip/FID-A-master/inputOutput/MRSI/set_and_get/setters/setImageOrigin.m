function MRSIStruct = setImageOrigin(MRSIStruct, value)
    MRSIStruct.imageOrgin = value;
end