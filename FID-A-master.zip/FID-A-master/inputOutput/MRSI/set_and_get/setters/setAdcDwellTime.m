function MRSIStruct = setAdcDwellTime(MRSIStruct, value)
    MRSIStruct.adcDwellTime = value;
end