function io_readDicom(FolderName)
    
end